package com.pactera.xiancheng;

public class AddMoneyThread implements Runnable{

	private Account account; // 存入账户
	private double money; // 存入金额
	
	public AddMoneyThread(Account account, double money){
		this.account = account;
		this.money = money;
	}
	@Override
	public void run() {
		synchronized (account) { //对银行账户进行同步
			account.deposit(money);
		}
		
		
	}

}
